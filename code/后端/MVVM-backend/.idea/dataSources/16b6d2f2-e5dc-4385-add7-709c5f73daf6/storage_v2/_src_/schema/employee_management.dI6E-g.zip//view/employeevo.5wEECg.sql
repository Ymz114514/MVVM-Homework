create definer = root@localhost view employeevo as
select `employee_management`.`employees`.`emp_id`       AS `emp_id`,
       `employee_management`.`employees`.`first_name`   AS `first_name`,
       `employee_management`.`employees`.`last_name`    AS `last_name`,
       `employee_management`.`employees`.`email`        AS `email`,
       `employee_management`.`employees`.`phone_number` AS `phone_number`,
       `employee_management`.`employees`.`hire_date`    AS `hire_date`,
       `employee_management`.`employees`.`job_title`    AS `job_title`,
       `employee_management`.`employees`.`salary`       AS `salary`,
       `employee_management`.`employees`.`dept_id`      AS `dept_id`,
       `employee_management`.`departments`.`dept_name`  AS `dept_name`
from (`employee_management`.`employees` join `employee_management`.`departments`
      on ((`employee_management`.`employees`.`dept_id` = `employee_management`.`departments`.`dept_id`)));

